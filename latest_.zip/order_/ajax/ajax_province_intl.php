<?php
include("../../admin/custom/static/general.php");
include("../../admin/static/general.php");

$country = $_POST['country'];


?>

<label class="col-md-3 control-label">City/State</label>
<div class="col-md-9">
  
	<div id="ajax_province">
		<input  type="text" name="checkout_user_province" class="form-control input-sm w50" id="id_checkout_user_province" value=""></input>
    </div>
</div>
