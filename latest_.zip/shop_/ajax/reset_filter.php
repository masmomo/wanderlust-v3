<?php
include("../../admin/custom/static/general.php");
include("../../admin/static/general.php");

unset($_SESSION['filters']);

echo 'success';
?>